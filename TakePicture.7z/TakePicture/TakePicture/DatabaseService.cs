﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using DAO;
//using PublicWCFServices;

namespace TakePicture
{
    class DatabaseService
    {
        static public Dictionary<string, string> _settings = new Dictionary<string, string>();
        static DataSource _ds = null;
        static DatabaseService()
        {
            //var client = new ConfigurationService();
            foreach (var key in ConfigurationManager.AppSettings.AllKeys)
            {
                _settings.Add(key, ConfigurationManager.AppSettings[key]);
            }

            foreach (ConnectionStringSettings cs in ConfigurationManager.ConnectionStrings)
            {
                _settings.Add(cs.Name, cs.ConnectionString);
            }

            //DataSource ds = null;

            if (_settings["dbProvider"] == "dedicatedServer")
                _ds = new DAO.Database(_settings);
            else if (_settings["dbProvider"] == "cloudServer")
                _ds = new DAO.CloudDatabase(_settings);
            else
                throw new Exception("Wrong database provider settings");
        }

        public byte[] GetImage(DAO.IMAGE_TYPE imageType, int id)
        {
            //DataSource ds = null;

            //if (_settings["dbProvider"] == "dedicatedServer")
            //    ds = new DAO.Database(_settings);
            //else if (_settings["dbProvider"] == "cloudServer")
            //    ds = new DAO.CloudDatabase(_settings);
            //else
            //    throw new Exception("Wrong database provider settings");

            return _ds.GetImage(imageType, Convert.ToInt32(id))[0];
        }

        public void SendImage(DAO.IMAGE_TYPE imageType, int id, ref byte[] buffer)
        {
            //DataSource ds = null;

            //if (_settings["dbProvider"] == "dedicatedServer")
            //    ds = new DAO.Database(_settings);
            //else if (_settings["dbProvider"] == "cloudServer")
            //    ds = new DAO.CloudDatabase(_settings);
            //else
            //    throw new Exception("Wrong database provider settings");

            _ds.SendImage(imageType, Convert.ToInt32(id), ref buffer);
        }

        /*
                string dbPictureTable;
                string dbFingerTable;

                string dbIdColumn = System.Configuration.ConfigurationManager.AppSettings["dbIdColumn"];
                string dbPictureColumn = System.Configuration.ConfigurationManager.AppSettings["dbPictureColumn"];
                string dbFingerColumn = System.Configuration.ConfigurationManager.AppSettings["dbFingerColumn"];

                internal DbDataService()
                {
                    dbPictureTable = getAppSetting("dbPictureTable");
                    dbFingerTable = getAppSetting("dbFingerTable");
                }

                public byte[] GetImage(IMAGE_TYPE imageType, int id)
                {
                    SqlConnection conn = null;
                    SqlCommand cmd = null;
                    SqlDataReader reader = null;

                    String stm;
                    byte[] buffer = null;

                    try
                    {
                        conn = new SqlConnection(getConnectionString());

                        conn.Open();

                        cmd = new SqlCommand();
                        cmd.Connection = conn;

                        if (imageType == IMAGE_TYPE.picture)
                            //stm = "SELECT " + dbPictureColumn + " FROM " + dbPictureTable + " WHERE " + dbIdColumn + " = " + id;
                            cmd.CommandText = "SELECT " + dbPictureColumn + " FROM " + dbPictureTable + " WHERE " + dbIdColumn + " = @id";
                        else
                            //stm = "SELECT " + dbFingerColumn + " FROM " + dbFingerTable + " WHERE " + dbIdColumn + " = " + id;
                            cmd.CommandText = "SELECT " + dbFingerColumn + " FROM " + dbFingerTable + " WHERE " + dbIdColumn + " = @id";

                        //cmd.CommandText = stm;
                        //cmd.Parameters.Add(new SqlCeParameter("@id", SqlDbType.Int));   // doesn't work
                        cmd.Parameters.AddWithValue("@id", id);


                        reader = cmd.ExecuteReader();
                        //reader.Read();

                        //SqlBinary binary;
                        //SqlBytes bytes;

                        //                if (reader.HasRows)   //Does not work for CE
                        if (reader.Read())
                        {
                            //if (!reader.IsDBNull(0))
                            //    id = reader.GetInt32(0);
                            if (!reader.IsDBNull(0))
                            {
                                //binary = reader.GetSqlBinary(1);
                                if (imageType == IMAGE_TYPE.picture)
                                    buffer = (byte[])reader[dbPictureColumn]; //(byte[])reader["AppImage"];
                                else
                                    buffer = (byte[])reader[dbFingerColumn]; //(byte[])reader["AppImage"];

                                //int maxSize = 200000;
                                //buffer = new byte[maxSize];
                                //reader.GetBytes(1, 0L, buffer, 0, maxSize);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        throw new Exception(ex.Message);
                    }
                    finally
                    {
                        try
                        {
                            if (reader != null)
                                reader.Close();

                            if (conn.State == ConnectionState.Open)
                                conn.Close();

                            if (conn != null)
                                conn = null;
                        }
                        catch (Exception ex)
                        {
                            throw new Exception(ex.Message);
                        }
                    }

                    return buffer;

                }

                public void SendImage(IMAGE_TYPE imageType, int id, ref byte[] buffer)
                {
                    SqlConnection conn = null;
                    SqlCommand cmd = null;
                    //object incrementId = null;
                    try
                    {
                        //System.Windows.Forms.MessageBox.Show("connect str1: " + getConnectionString());
                        conn = new SqlConnection(getConnectionString());

                        conn.Open();

                        cmd = new SqlCommand();
                        cmd.Connection = conn;

                        string dbImageTable, dbImageColumn;
                        if (imageType == IMAGE_TYPE.picture)
                        {
                            dbImageTable = dbPictureTable;
                            dbImageColumn = dbPictureColumn;
                        }
                        else
                        {
                            dbImageTable = dbFingerTable;
                            dbImageColumn = dbFingerColumn;
                        }

                        cmd.CommandText = String.Format(@"
                                    begin tran
                                        update {0} with (serializable) SET {1} = @picture where {2} = @id
                                        if @@rowcount = 0 
                                        begin
                                            insert into {0} ({2}, {1}) values (@id, @picture) 
                                        end
                                    commit tran ", dbImageTable, dbImageColumn, dbIdColumn);

                        cmd.Parameters.Add("@picture", SqlDbType.VarBinary);
                        cmd.Parameters["@picture"].Value = buffer;

                        cmd.Parameters.Add("@id", SqlDbType.Int);
                        cmd.Parameters["@id"].Value = id;

                        cmd.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        //System.Windows.Forms.MessageBox.Show(ex.Message);
                        throw new Exception(ex.Message);
                    }
                    finally
                    {
                        try
                        {
                            if (conn.State == ConnectionState.Open)
                                conn.Close();

                            if (conn != null)
                                conn = null;
                        }
                        catch (Exception ex)
                        {
                            throw new Exception(ex.Message);
                        }
                    }
                }

                private String getConnectionString()
                {
                    return ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
                }

                private String getAppSetting(string key)
                {
                    var setting = ConfigurationManager.AppSettings[key];
                    // If we didn't find setting, try to load it from current dll's config file
                    if (string.IsNullOrEmpty(setting))
                    {
                        var filename = System.Reflection.Assembly.GetExecutingAssembly().Location;
                        var configuration = ConfigurationManager.OpenExeConfiguration(filename);
                        if (configuration != null)
                            setting = configuration.AppSettings.Settings[key].Value;
                    }

                    return setting;
                }
*/
    }
}
