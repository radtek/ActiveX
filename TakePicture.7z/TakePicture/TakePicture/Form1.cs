﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Threading;
using System.Security.Permissions;
using System.Runtime.InteropServices;
using System.Configuration;
//using PublicWCFServices;

namespace TakePicture
{
    public partial class Form1 : Form
    {

        //private BackgroundWorker backgroundWorker = null;
        //private IntPtr hWnd;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox1.Text = "20005140";
            //textBox1.Text = "20095423"; 
            IntPtr hWnd = pictureBox1.Handle;
            StartPreview(hWnd, pictureBox1.Width, pictureBox1.Height);

            btnTake.Enabled = true;
            btnGet.Enabled = true;
            btnTake.Focus();
        }

        private void btnTake_Click(object sender, EventArgs e)
        {
            int id;
            if (textBox1.Text.Length == 0 || !Int32.TryParse(textBox1.Text, out id))
            {
                System.Windows.Forms.MessageBox.Show("Please enter a valid ID");
                return;
            }

            btnTake.Enabled = false;
            btnGet.Enabled = false;
            //long length = MakeOneShot();

            //System.Diagnostics.Debugger.Break();

            //String fileName2 = Environment.GetFolderPath(Environment.SpecialFolder.InternetCache) + "\\r.jpg";
            //String fileName2 = Path.GetDirectoryName(Application.ExecutablePath) + "\\r.jpg";
            String fileName = "EMP_PICS.bmp";
            //String fileName = "c:\\temp\\rid50_pic.bmp";

            //new FileIOPermission(PermissionState.Unrestricted).Assert();
            TakeSnap(fileName);

            //IntPtr hWnd = pictureBox1.Handle;
            //StartPreview(hWnd);

            FileStream fs = null;
            MemoryStream ms = null;
            try
            {
                //fs = new FileStream(fileName2, FileMode.Open);
                fs = new FileStream(fileName, FileMode.Open);
                BinaryReader br = new BinaryReader(fs);
                //MessageBox.Show("fs.Length : " + fs.Length);
                byte[] buffer = br.ReadBytes((int)fs.Length);
                fs.Close();
                //Image img = Image.FromStream(fs);

                ms = new MemoryStream(buffer);
                Image img = Image.FromStream(ms);

                pictureBox2.Image = img;

                //img.Save("c:\\aaa.jpg", ImageFormat.Jpeg);
                //MemoryStream mem = new MemoryStream();
                //img.Save(mem, System.Drawing.Imaging.ImageFormat.Jpeg);
                //byte[] buff = mem.ToArray();

                btnTake.Focus();

                ms.Close();

                Bitmap bmp = new Bitmap(img);
                Helper.saveJpegToStream(out ms, bmp, 20L);
                //GrabImageClient.Helper.saveJpegToFile("c:\\temp\\kuku2.jpg", bmp, 20L);
                bmp.Dispose();

                buffer = ms.ToArray();

                //Bitmap bmp = new Bitmap(img);
                //Helper.saveJpegToStream(out ms, bmp, 50L);
                //bmp.Dispose();
                //img = Image.FromStream(ms);
                //img.Save("aaa50quality.jpg", ImageFormat.Jpeg);

                //Helper.saveJpeg("EMP_PICS.jpg", new Bitmap(img), 100L);

                //System.Diagnostics.Debugger.Break();
                //__debugbreak();

                //if (String.IsNullOrEmpty(textBox1.Text))

                //DBUtil db = new DBUtil();
                //db.SavePicture(id, ref buffer);

                //IDataService service = null;
                dynamic client = null;
                dynamic imageType = null;

                imageType = DAO.IMAGE_TYPE.picture;
                if (ConfigurationManager.AppSettings["dbProvider"] == "dedicatedServer")
                    client = new DatabaseService();
                //else if (ConfigurationManager.AppSettings["dbProvider"] == "cloudServer")
                //    client = new WebDataService();
                else if (ConfigurationManager.AppSettings["dbProvider"] == "cloudServerProxy")
                {
                    client = new ProxyWebDataService.WebDataServiceClient();
                    imageType = ProxyWebDataService.IMAGE_TYPE.picture;
                }
                else if (ConfigurationManager.AppSettings["dbProvider"] == "dedicatedServerProxy")
                {
                    client = new ProxyDbDataService.DbDataServiceClient();
                    imageType = ProxyDbDataService.IMAGE_TYPE.picture;
                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("Wrong AppSettings[\"dbProvider\"] setting");
                    return;
                }

                if (client == null)
                {
                    System.Windows.Forms.MessageBox.Show("Service " + ConfigurationManager.AppSettings["dbProvider"] + " is unavailable");
                    return;
                }

                //client.ClientCredentials.Windows.AllowedImpersonationLevel = System.Security.Principal.TokenImpersonationLevel.Impersonation;
                client.SendImage(imageType, id, ref buffer);

                //WebService webService = new WebService();
                //webService.UploadPicture(id, ref buffer);

                //textBox1.Text = db.SavePicture(VisitorsDatabase, mode, textBox1.Text, ref buffer);
                //System.Windows.Forms.MessageBox.Show("Id: " + id.ToString());
                //textBox1.Text = id.ToString();

                Thread.Sleep(2000);

                //buffer = db.GetPicure(1);

            }
            catch (Exception ex) {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                //FileIOPermission.RevertAssert();
                if (fs != null)
                    fs.Close();
                if (ms != null)
                    ms.Close();
                btnTake.Enabled = true;
                btnGet.Enabled = true;

                //File.Delete(fileName);
            }
        }

        private void btnGet_Click(object sender, EventArgs e)
        {
            //MessageBox.Show("Background: " + Background);
            //this.BackColor = ColorTranslator.FromHtml(Background);

            int id;
            if (textBox1.Text.Length == 0 || !Int32.TryParse(textBox1.Text, out id))
            {
                System.Windows.Forms.MessageBox.Show("Please enter a valid ID");
                return;
            }

            btnTake.Enabled = false;
            btnGet.Enabled = false;

            //String fileName = Environment.GetFolderPath(Environment.SpecialFolder.InternetCache) + "\\rid50_pic.bmp";

            //DBUtil db = new DBUtil();
            //buffer = db.GetPicture(id);
            //WebService webService = new WebService();
            dynamic client = null;
            dynamic imageType = null;
            //TakePicture.ProxyDbDataService.DbDataServiceClient service = null;

            //FileStream fs = null;
            byte[] buffer = null;
            MemoryStream ms = null;
            try
            {
                imageType = DAO.IMAGE_TYPE.picture;
                client = new DatabaseService();
/*
                //buffer = webService.GetPicture(id);
                imageType = DAO.IMAGE_TYPE.picture;
                if (ConfigurationManager.AppSettings["dbProvider"] == "dedicatedServer")
                    client = new DatabaseService();
                //else if (ConfigurationManager.AppSettings["dbProvider"] == "cloudServer")
                //    client = new WebDataService();
                else if (ConfigurationManager.AppSettings["dbProvider"] == "cloudServerProxy")
                {
                    client = new ProxyWebDataService.WebDataServiceClient();
                    imageType = ProxyWebDataService.IMAGE_TYPE.picture;
                }
                else if (ConfigurationManager.AppSettings["dbProvider"] == "dedicatedServerProxy")
                {
                    client = new ProxyDbDataService.DbDataServiceClient();
                    imageType = ProxyDbDataService.IMAGE_TYPE.picture;
                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("Wrong AppSettings[\"dbProvider\"] setting");
                    return;
                }
*/
                //if (client == null)
                //{
                //    System.Windows.Forms.MessageBox.Show("Service " + ConfigurationManager.AppSettings["dbProvider"] + " is unavailable");
                //    return;
                //}

                try
                {
                    client.ClientCredentials.Windows.ClientCredential.UserName = "psc";
                    client.ClientCredentials.Windows.ClientCredential.Password = "psc";
                    //client.Credentials = System.Net.CredentialCache.DefaultCredentials;
                    //client.Credentials = new System.Net.NetworkCredential("psc", "psc");

                    client.ClientCredentials.Windows.AllowedImpersonationLevel = System.Security.Principal.TokenImpersonationLevel.Impersonation;
                } catch(Exception) {}

                buffer = client.GetImage(imageType, id);

                if (buffer == null)
                {
                    System.Windows.Forms.MessageBox.Show("No picture with Id '" + textBox1.Text + "' exists");
                    return;
                }

                //MessageBox.Show(buffer.Length.ToString());
                ms = new MemoryStream(buffer);
                Image img = Image.FromStream(ms);

                pictureBox2.Image = img;

                btnTake.Focus();

                ms.Close();
            }
            catch (Exception ex){
                if (ex.InnerException != null)
                    ex = ex.InnerException;

                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                if (ms != null)
                    ms.Close();
                btnTake.Enabled = true;
                btnGet.Enabled = true;
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            DestroyGraph();
        }
    }
}
