﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;

namespace TakePicture
{
    public partial class Form1
    {
        [DllImport("GrabImage.dll", CharSet = CharSet.Auto)]
        public static extern int StartPreview(IntPtr handle, int width, int height);

        //[DllImport("GrabImage.dll", CharSet = CharSet.Auto)]
        //public static extern long MakeOneShot();

        [DllImport("GrabImage.dll", CharSet = CharSet.Ansi)]
        public static extern int TakeSnap(String fileName);
        //public static extern void TakeSnap(System.Text.StringBuilder fileName);
        //public static extern void TakeSnap(char[] fileName);

        [DllImport("GrabImage.dll", CharSet = CharSet.Auto)]
        public static extern void DestroyGraph();
    }
}
